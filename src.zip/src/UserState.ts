class UserState {
    public static NEW = "new"
    public static ACTIVE = "active"
    public static BLOCKED = "blocked"
    public static BANNED = "banned" 
}

export {UserState}