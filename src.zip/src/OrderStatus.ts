export class OrderStatus{
    public static NEW = "new"
    public static HOLD = "Hold"
    public static SHIPPED = "Shipped"
    public static DELIVERED = "Delivered"
    public static CLOSED = "Closed"
}